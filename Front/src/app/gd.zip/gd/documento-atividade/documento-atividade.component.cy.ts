import { DocumentoAtividadeComponent } from './documento-atividade.component'

describe('DocumentoAtividadeComponent', () => {
  it('should mount', () => {
    cy.mount(DocumentoAtividadeComponent)
  })
})