import { RegistarDocumentoComponent } from './registar-documento.component'

describe('RegistarDocumentoComponent', () => {
  it('should mount', () => {
    cy.mount(RegistarDocumentoComponent)
  })
})