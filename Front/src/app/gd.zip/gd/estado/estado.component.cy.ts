import { EstadoComponent } from './estado.component'

describe('EstadoComponent', () => {
  it('should mount', () => {
    cy.mount(EstadoComponent)
  })
})