import { EntidadeComponent } from './entidade.component'

describe('EntidadeComponent', () => {
  it('should mount', () => {
    cy.mount(EntidadeComponent)
  })
})