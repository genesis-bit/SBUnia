import { DocumentoDespachoComponent } from './documento-despacho.component'

describe('DocumentoDespachoComponent', () => {
  it('should mount', () => {
    cy.mount(DocumentoDespachoComponent)
  })
})