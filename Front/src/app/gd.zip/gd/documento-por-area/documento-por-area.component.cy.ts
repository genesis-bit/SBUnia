import { DocumentoPorAreaComponent } from './documento-por-area.component'

describe('DocumentoPorAreaComponent', () => {
  it('should mount', () => {
    cy.mount(DocumentoPorAreaComponent)
  })
})