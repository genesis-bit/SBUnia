import { VerDocumentoSituacaoComponent } from './ver-documento-situacao.component'

describe('VerDocumentoSituacaoComponent', () => {
  it('should mount', () => {
    cy.mount(VerDocumentoSituacaoComponent)
  })
})