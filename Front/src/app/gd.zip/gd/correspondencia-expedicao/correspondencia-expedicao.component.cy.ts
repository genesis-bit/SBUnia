import { CorrespondenciaExpedicaoComponent } from './correspondencia-expedicao.component'

describe('CorrespondenciaExpedicaoComponent', () => {
  it('should mount', () => {
    cy.mount(CorrespondenciaExpedicaoComponent)
  })
})