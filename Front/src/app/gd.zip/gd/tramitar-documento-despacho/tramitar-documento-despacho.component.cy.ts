import { TramitarDocumentoDespachoComponent } from './tramitar-documento-despacho.component'

describe('TramitarDocumentoDespachoComponent', () => {
  it('should mount', () => {
    cy.mount(TramitarDocumentoDespachoComponent)
  })
})