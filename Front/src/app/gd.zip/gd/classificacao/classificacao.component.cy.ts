import { ClassificacaoComponent } from './classificacao.component'

describe('ClassificacaoComponent', () => {
  it('should mount', () => {
    cy.mount(ClassificacaoComponent)
  })
})