import { DocumentoEstadoComponent } from './documento-estado.component'

describe('DocumentoEstadoComponent', () => {
  it('should mount', () => {
    cy.mount(DocumentoEstadoComponent)
  })
})