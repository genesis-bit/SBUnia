import { DocumentosSituacaoComponent } from './documentos-situacao.component'

describe('DocumentosSituacaoComponent', () => {
  it('should mount', () => {
    cy.mount(DocumentosSituacaoComponent)
  })
})