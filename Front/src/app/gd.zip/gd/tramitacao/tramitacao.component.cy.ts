import { TramitacaoComponent } from './tramitacao.component'

describe('TramitacaoComponent', () => {
  it('should mount', () => {
    cy.mount(TramitacaoComponent)
  })
})