import { ViaTransmissaoDocumentoComponent } from './via-transmissao-documento.component'

describe('ViaTransmissaoDocumentoComponent', () => {
  it('should mount', () => {
    cy.mount(ViaTransmissaoDocumentoComponent)
  })
})