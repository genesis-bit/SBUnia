import { TipoDocumentoComponent } from './tipo-documento.component'

describe('TipoDocumentoComponent', () => {
  it('should mount', () => {
    cy.mount(TipoDocumentoComponent)
  })
})