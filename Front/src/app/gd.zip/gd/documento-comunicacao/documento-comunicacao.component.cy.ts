import { DocumentoComunicacaoComponent } from './documento-comunicacao.component'

describe('DocumentoComunicacaoComponent', () => {
  it('should mount', () => {
    cy.mount(DocumentoComunicacaoComponent)
  })
})