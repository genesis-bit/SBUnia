import { EditarDocumentoPorAreaComponent } from './editar-documento-por-area.component'

describe('EditarDocumentoPorAreaComponent', () => {
  it('should mount', () => {
    cy.mount(EditarDocumentoPorAreaComponent)
  })
})