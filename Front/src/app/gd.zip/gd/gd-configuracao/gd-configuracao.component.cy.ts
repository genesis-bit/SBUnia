import { GdConfiguracaoComponent } from './gd-configuracao.component'

describe('GdConfiguracaoComponent', () => {
  it('should mount', () => {
    cy.mount(GdConfiguracaoComponent)
  })
})