import { CorrespondenciaEstadosComponent } from './correspondencia-estados.component'

describe('CorrespondenciaEstadosComponent', () => {
  it('should mount', () => {
    cy.mount(CorrespondenciaEstadosComponent)
  })
})