import { PrioridadeDocumentoComponent } from './prioridade-documento.component'

describe('PrioridadeDocumentoComponent', () => {
  it('should mount', () => {
    cy.mount(PrioridadeDocumentoComponent)
  })
})