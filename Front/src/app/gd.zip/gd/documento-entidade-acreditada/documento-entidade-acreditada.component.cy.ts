import { DocumentoEntidadeAcreditadaComponent } from './documento-entidade-acreditada.component'

describe('DocumentoEntidadeAcreditadaComponent', () => {
  it('should mount', () => {
    cy.mount(DocumentoEntidadeAcreditadaComponent)
  })
})