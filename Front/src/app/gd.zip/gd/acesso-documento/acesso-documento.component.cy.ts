import { AcessoDocumentoComponent } from './acesso-documento.component'

describe('AcessoDocumentoComponent', () => {
  it('should mount', () => {
    cy.mount(AcessoDocumentoComponent)
  })
})