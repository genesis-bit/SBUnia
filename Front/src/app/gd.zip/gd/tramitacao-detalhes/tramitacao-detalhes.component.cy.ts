import { TramitacaoDetalhesComponent } from './tramitacao-detalhes.component'

describe('TramitacaoDetalhesComponent', () => {
  it('should mount', () => {
    cy.mount(TramitacaoDetalhesComponent)
  })
})