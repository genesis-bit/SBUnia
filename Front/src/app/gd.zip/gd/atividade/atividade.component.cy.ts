import { AtividadeComponent } from './atividade.component'

describe('AtividadeComponent', () => {
  it('should mount', () => {
    cy.mount(AtividadeComponent)
  })
})