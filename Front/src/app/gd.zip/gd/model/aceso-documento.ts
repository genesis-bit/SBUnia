export class Acesso_documento {
  id: number;
  estado: number;
  nome: string;
  descricao: string;
}
