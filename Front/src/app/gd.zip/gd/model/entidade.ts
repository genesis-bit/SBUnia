export class Entidade {
  id: number;
  nome: string;
  endereco: string;
  email: string;
  telefone: string;
  estado: number;
}
