export class Ordem_referencia {
  id: number;
  gd_documento_id: number;
  data_documento: any;
  estado: number;
  ordem_referencia: string;
  motivo: string;
  novo_estado: number;
  novo_estado_descricao: string;
}
