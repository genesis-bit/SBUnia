export class Documento_despacho {
  id: number;
  nome: string;
  cor: string;
  estado: number;
}
