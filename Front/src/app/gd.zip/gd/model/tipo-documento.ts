export class Tipo_documento {
  id: number;
  codigo: number;
  estado: number;
  nome: string;
  sigla: string;
}
