export class Expedicao {

  id:number;
  periodo_tratamento: number;
  receptor: string;
  expedido_fisico: number;
  expedido_email: number;
  data_expedicao: any;
  notificacao_enviada: any;
}
