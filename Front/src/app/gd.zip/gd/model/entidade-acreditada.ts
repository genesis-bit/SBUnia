export class Entidade_acreditada {
  id: number;
  base_area_id: number;
  base_orgao_id: number;
  user_id: number;
  entidade_id: number;
  gd_comunicacao_id: number;
  data_recebimento: any;
  data_envio:any;
  observacao: string;
  despacho: string;
  estado: number;
  visualizar: number;
  editar: string;
  gd_documento_id: number;
}
