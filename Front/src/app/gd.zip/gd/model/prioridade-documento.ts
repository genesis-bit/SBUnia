export class Prioridade_documento {
  id: number;
  nome: string; // único
  tempo: number;
  estado: any;
  cor: string; // único
}
