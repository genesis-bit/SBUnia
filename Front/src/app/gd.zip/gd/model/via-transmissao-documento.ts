export class Via_transmissao {
  id: number;
  nome: string;
  estado: number;
}
