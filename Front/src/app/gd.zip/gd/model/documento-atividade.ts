export class Documento_atividade {
  id: number;
  nome: string;
  cor: string;
  estado: number;
}
