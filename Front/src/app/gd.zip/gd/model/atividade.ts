export class Atividade {
  id: number;
  nome: string;
  codigo_documento: string;
  data_documento: any;
  assunto: string;
  texto: string;
  estado: number;
  base_area_id: number;
  gd_tipo_documento_id: number;
  base_anexo_id: number;
  gd_prioridade_documento_id: number;
  user: number;
  periodo_tratamento: number;
  icon: string;
}
