export class Estado {
  id: number;
  nome: string;
  cor: string;
  estado: number;
  descricao: string;
}
