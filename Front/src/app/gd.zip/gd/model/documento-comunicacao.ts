export class Documento_comunicacao {
  id: number;
  nome: string;
  estado: number;
}
