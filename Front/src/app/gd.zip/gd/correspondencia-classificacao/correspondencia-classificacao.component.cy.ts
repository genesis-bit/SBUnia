import { CorrespondenciaClassificacaoComponent } from './correspondencia-classificacao.component'

describe('CorrespondenciaClassificacaoComponent', () => {
  it('should mount', () => {
    cy.mount(CorrespondenciaClassificacaoComponent)
  })
})