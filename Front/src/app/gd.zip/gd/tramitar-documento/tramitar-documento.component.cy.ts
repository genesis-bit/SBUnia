import { TramitarDocumentoComponent } from './tramitar-documento.component'

describe('TramitarDocumentoComponent', () => {
  it('should mount', () => {
    cy.mount(TramitarDocumentoComponent)
  })
})