import { CorrespondenciaRegistoComponent } from './correspondencia-registo.component'

describe('CorrespondenciaRegistoComponent', () => {
  it('should mount', () => {
    cy.mount(CorrespondenciaRegistoComponent)
  })
})