import { OrdemReferenciaComponent } from './ordem-referencia.component'

describe('OrdemReferenciaComponent', () => {
  it('should mount', () => {
    cy.mount(OrdemReferenciaComponent)
  })
})